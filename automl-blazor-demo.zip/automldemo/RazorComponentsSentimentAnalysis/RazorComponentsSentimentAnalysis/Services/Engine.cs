﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace RazorComponentsSentimentAnalysis.Services
{
    public class Engine
    {
        static MLContext context = new MLContext();
        static ITransformer model
            = context.Model.Load(File.Open("model.zip", FileMode.Open));

        [ThreadStatic]
        static PredictionEngine<SourceData, Prediction> t_engine;

        public static PredictionEngine<SourceData, Prediction> GetPredictionEngine(string modelfile)
        {
            if (t_engine != null)
                return t_engine;

            return t_engine = model.CreatePredictionEngine<SourceData, Prediction>(context);
        }

        public static float CalculatePercentage(double value)
        {
            return 100 * (1.0f / (1.0f + (float)Math.Exp(-value)));
        }
    }
}
