﻿using static RazorComponentsSentimentAnalysis.Services.Engine;

namespace RazorComponentsSentimentAnalysis.Services
{
    // Model input
    public class SourceData
    {
        public string SentimentText { get; set; }
    }
    // Model output
    public class Prediction
    {
        public float Percentage => CalculatePercentage(Score);
        public bool PredictedLabel { get; set; }
        public float Score { get; set; }
        
    }
    public static class Sentiment
    {
        public static Prediction Predict(string text)
        {
            var engine = GetPredictionEngine("model.zip");
            return engine.Predict(new SourceData { SentimentText = text });
        }
    }
}