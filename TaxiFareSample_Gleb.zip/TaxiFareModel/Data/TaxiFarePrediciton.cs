﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiFare.Data
{
    public class Prediction
    {
        public float Score { get; set; }
    }
}
